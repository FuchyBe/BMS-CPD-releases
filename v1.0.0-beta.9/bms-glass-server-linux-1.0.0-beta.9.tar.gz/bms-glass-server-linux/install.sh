#!/bin/sh
# BMS Glass Server — installation sous Linux (systemd).
#
#   sudo ./install.sh [--port 8844] [--players 32|48] [--password-file FICHIER]
#                     [--import ANCIEN_DOSSIER_RELAY] [--binary CHEMIN]
#
# Crée l'utilisateur système bms-glass-server, le dossier
# /var/lib/bms-glass-server (0700), installe /usr/local/bin/bms-glass-server
# et l'unité systemd, ouvre le port TCP (ufw ou firewalld s'ils sont actifs)
# et démarre le service. Relancer le script = mise à jour (les données et
# réglages sont gardés). Désinstaller : sudo ./install.sh --uninstall [--purge]
set -eu

PORT=""; PLAYERS=""; PWFILE=""; IMPORT=""; BIN=""; UNINSTALL=0; PURGE=0
USER_NAME=bms-glass-server
DATA=/var/lib/bms-glass-server
DEST=/usr/local/bin/bms-glass-server
UNIT=/etc/systemd/system/bms-glass-server.service
HERE=$(cd "$(dirname "$0")" && pwd)

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    --players) PLAYERS="$2"; shift 2 ;;
    --password-file) PWFILE="$2"; shift 2 ;;
    --import) IMPORT="$2"; shift 2 ;;
    --binary) BIN="$2"; shift 2 ;;
    --uninstall) UNINSTALL=1; shift ;;
    --purge) PURGE=1; shift ;;
    -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
    *) echo "option inconnue : $1" >&2; exit 2 ;;
  esac
done

[ "$(id -u)" = 0 ] || { echo "à lancer avec sudo" >&2; exit 1; }
command -v systemctl >/dev/null || { echo "systemd introuvable (voir le Dockerfile pour un conteneur)" >&2; exit 1; }

current_port() {
  sed -n 's/.*"port": *\([0-9][0-9]*\).*/\1/p' "$DATA/server.json" 2>/dev/null | head -n1
}

firewall() { # $1 = add | remove, $2 = port
  [ -n "$2" ] || return 0
  if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
    if [ "$1" = add ]; then ufw allow "$2/tcp" comment "BMS Glass Server" >/dev/null; else ufw delete allow "$2/tcp" >/dev/null 2>&1 || true; fi
    echo "ufw : port $2/tcp $( [ "$1" = add ] && echo ouvert || echo refermé )"
  fi
  if command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
    if [ "$1" = add ]; then firewall-cmd -q --permanent --add-port="$2/tcp"; else firewall-cmd -q --permanent --remove-port="$2/tcp" || true; fi
    firewall-cmd -q --reload
    echo "firewalld : port $2/tcp $( [ "$1" = add ] && echo ouvert || echo refermé )"
  fi
}

if [ "$UNINSTALL" = 1 ]; then
  P=$(current_port)
  systemctl disable --now bms-glass-server 2>/dev/null || true
  rm -f "$UNIT" "$DEST"
  systemctl daemon-reload
  firewall remove "${P:-8844}"
  if [ "$PURGE" = 1 ]; then
    rm -rf "$DATA"; userdel "$USER_NAME" 2>/dev/null || true
    echo "BMS Glass Server désinstallé (données supprimées)"
  else
    echo "BMS Glass Server désinstallé (données gardées dans $DATA ; --purge pour les supprimer)"
  fi
  exit 0
fi

if [ -z "$BIN" ]; then
  case "$(uname -m)" in
    x86_64|amd64) A=amd64 ;;
    aarch64|arm64) A=arm64 ;;
    *) echo "architecture $(uname -m) non prise en charge" >&2; exit 1 ;;
  esac
  for c in "$HERE/bms-glass-server-linux-$A" "$HERE/bms-glass-server" "$HERE/../../dist/bms-glass-server-linux-$A"; do
    [ -f "$c" ] && { BIN="$c"; break; }
  done
fi
[ -n "$BIN" ] && [ -f "$BIN" ] || { echo "binaire introuvable : --binary <bms-glass-server-linux-…>" >&2; exit 1; }

if ! id "$USER_NAME" >/dev/null 2>&1; then
  useradd --system --home-dir "$DATA" --no-create-home --shell /usr/sbin/nologin "$USER_NAME" 2>/dev/null \
    || useradd -r -d "$DATA" -s /sbin/nologin "$USER_NAME"
fi
install -d -m 0700 -o "$USER_NAME" -g "$USER_NAME" "$DATA"
OLDPORT=$(current_port)
systemctl stop bms-glass-server 2>/dev/null || true
install -m 0755 "$BIN" "$DEST"

INIT="-init -data $DATA"
[ -n "$PORT" ] && INIT="$INIT -port $PORT"
[ -n "$PLAYERS" ] && INIT="$INIT -players $PLAYERS"
TMPPW=""
if [ -n "$PWFILE" ]; then
  TMPPW=$(mktemp); cp "$PWFILE" "$TMPPW"; chown "$USER_NAME" "$TMPPW"; chmod 600 "$TMPPW"
  INIT="$INIT -password-file $TMPPW"
fi
if [ -n "$IMPORT" ]; then
  TMPIMP=$(mktemp -d); cp "$IMPORT"/relay-* "$TMPIMP"/ ; chown -R "$USER_NAME" "$TMPIMP"
  INIT="$INIT -import $TMPIMP"
fi
# shellcheck disable=SC2086
runuser -u "$USER_NAME" -- "$DEST" $INIT
[ -n "$TMPPW" ] && rm -f "$TMPPW"
[ -n "${TMPIMP:-}" ] && rm -rf "$TMPIMP"

install -m 0644 "$HERE/bms-glass-server.service" "$UNIT"
systemctl daemon-reload
systemctl enable --now bms-glass-server

NEWPORT=$(current_port)
[ -n "$OLDPORT" ] && [ "$OLDPORT" != "$NEWPORT" ] && firewall remove "$OLDPORT"
firewall add "${NEWPORT:-8844}"

sleep 1
echo
cat "$DATA/relay-info.txt" 2>/dev/null || true
echo
echo "Service : systemctl status bms-glass-server · journal : $DATA/relay.log"
grep -q passwordHash "$DATA/server.json" 2>/dev/null \
  || echo "Mot de passe d'administration à distance non défini : sudo ./install.sh --password-file <fichier>, ou page locale (ssh -L 8845:127.0.0.1:8845)."
