# BMS-CPD 0.7.2-beta

CPD de F-16 Block 70/72 sur tablette Android, connecté à Falcon BMS 4.38.
Version portable : rien à installer, tout reste dans le dossier de l'exe.

## 1. Premier lancement (sans BMS, pour essayer)

1. Mets `BMS-CPD.exe` dans un dossier à lui (ex. `C:\Outils\BMS-CPD\`).
2. Lance-le **en mode démo** : clic droit dans le dossier → Terminal →
   `.\BMS-CPD.exe --mock`
   Un vol simulé en Corée démarre, et la page de réglages s'ouvre dans ton navigateur.
3. Autorise l'exe dans le pare-feu Windows (réseau **privé**) quand Windows le demande.

Pour l'usage normal avec BMS, lance simplement `BMS-CPD.exe` (double-clic).

## 2. Réglages BMS (une seule fois)

**Le plus simple :** dans la page de réglages de BMS-CPD, **Accueil** → « Corriger »
(ou page **Falcon BMS** → « Corriger le fichier »). Tu peux aussi
activer « Corriger automatiquement au démarrage » (page Falcon BMS).
Une sauvegarde `.bak` du fichier est faite avant chaque modification.
Redémarre BMS ensuite.

Le fichier se trouve dans le dossier d'installation de BMS, par exemple
`C:\Falcon BMS 4.38\User\Config\Falcon BMS User.cfg`. S'il n'existe pas,
BMS-CPD le crée. À la main, il faut y mettre :

```
set g_bExportRTTTextures 1     // copie des MFD pour le 3e MFD
set g_bTacviewRealTime 1       // datalink (optionnel, vue de tous les objets)
set g_bBriefHTML 1             // briefing en HTML (sinon texte)
```

Si tu passes par l'Alternative Launcher, vérifie qu'il n'écrase pas ce fichier.
Pour afficher le briefing sur la tablette, utilise le bouton « Print » dans l'écran
de briefing de BMS : le fichier est écrit dans `User\Briefings`.

## 3. Connecter la tablette

**Wi-Fi** : PC et tablette sur le même réseau. Ouvre dans Chrome l'adresse
affichée dans la console (ex. `http://192.168.1.20:8740`), puis touche ⛶ pour
passer en plein écran.

**USB (adb)** : active le débogage USB sur la tablette, branche-la, et clique
« Activer l'USB » dans la page de réglages (page **Tablette**) (il faut `adb.exe`, par ex. les
*platform-tools* Android à côté de l'exe). Sur la tablette, ouvre
`http://localhost:8740`. En USB, Chrome permet « Ajouter à l'écran d'accueil » :
l'appli s'ouvre alors en vrai plein écran.

**USB en écran étendu** : si la tablette est un moniteur Windows (spacedesk,
SuperDisplay…), choisis le moniteur dans la page de réglages (page **Tablette**,
« Écran étendu ») et clique « Ouvrir le CPD ici ». Dans ce mode, après chaque toucher sur le CPD,
BMS-CPD rend le focus à BMS et remet le curseur de la souris où il était ; la
fenêtre du CPD est aussi marquée « non activable » pour ne pas passer au
premier plan. Le mode Wi-Fi ou USB (navigateur de la tablette) n'a jamais ce
problème : c'est le mode recommandé.

## 4. Documents par théâtre (cartes, charts, navaids)

La page **DOCS** de la tablette a deux vues, choisies par les deux premiers OSB
de gauche :

- **CHRT** (par défaut) : les cartes d'aérodrome du **théâtre en cours**
  seulement. En haut, les cartes **épinglées** ; dessous, un bloc **par pays**
  (une touche le déplie / replie), puis une ligne par aérodrome (code OACI +
  nom ; s'il a plusieurs cartes, la ligne se déplie : ILS 27, TACAN 09…).
  Le champ filtre accepte un code OACI ou un nom. **PIN** (à droite de chaque
  carte, ou OSB **PIN** dans la visionneuse) épingle la carte pour ce théâtre ;
  **RST PIN** (à *maintenir*) retire toutes les épingles du théâtre.
  **EXP ALL / COL ALL** déplie / replie tous les pays, **NAV** ouvre la liste
  des navaids du théâtre.
- **DOCS** : l'explorateur complet — raccourcis du théâtre, favoris ★, dossier
  `Docs` de BMS ; **ALL** affiche les raccourcis de tous les théâtres.

Une carte (ou un document) s'ouvre **en plein écran** ; **RET** rend l'écran
tel qu'il était (split, pages). Dans la visionneuse : **PAGE ▲/▼**, **FIT W/P**,
**CHRT ▲/▼** (carte précédente / suivante du même aérodrome), **ZOOM + / −**,
**NGT**, **ROT**, **PIN**, **NAV LIST** ; pincer pour zoomer.

Les cartes sont lues dans les raccourcis du théâtre dont le nom contient
« Charts » (préremplis pour Korea, Balkans, Hellas et Israel : dossier
`…\Charts\<pays>\…`, un sous-dossier par pays, éventuellement un par
aérodrome) ; le code OACI est repris du nom du fichier (`LQSA Sarajevo.pdf`,
`RKSO ILS 27.pdf`) ou du sous-dossier. La liste des navaids est le raccourci
dont le nom contient « navaids ».

Pour ajouter un raccourci : page de réglages du PC → **Théâtres** → choisir le
théâtre → « Documents du théâtre » → nom, chemin d'un **dossier** (navigable sur la tablette) ou d'un
**fichier**. Chemin absolu (`D:\Cartes\Korea`) ou relatif au dossier BMS
(`Data\Add-On Balkans\Docs\02 Maps`). Majuscules, espaces en trop et extension
manquante sont tolérés. Les dossiers `Docs` de chaque add-on sont ajoutés
automatiquement.

Depuis la page **TSD** :
- **APT** ouvre la recherche de cartes d'aérodrome : onglets **OACI** (code,
  ex. LQSA), **NOM** (ex. Sarajevo), **TOUT**, et **NAVAIDS** (liste des navaids
  du théâtre en cours). La recherche porte sur les noms de fichiers des dossiers
  du théâtre et du dossier Docs de BMS. La carte s'ouvre **en plein écran** ;
  l'OSB **RET TSD** rend l'écran tel qu'il était (split, pages). Réglage SET →
  « Cartes APT / NAV » : plein écran ou autre moitié.
- **LBL** et **RING** : libellés et anneaux de distance, séparés.
- **Lignes du DTC** (L1 à L4, tracées par le créateur de mission ou dans le
  planificateur) : affichées avec le plan de vol (OSB **FPLN**), une couleur
  par ligne, nom de la ligne avec **LBL**.
- **DL** : **AWACS** (par défaut) → **AMIS** → **OFF**. En AWACS, les amis sont
  toujours affichés et un ennemi seulement s'il est vu par un AWACS ami (E-3,
  E-767, A-50…, ou indicatif DARKSTAR, MAGIC…) : dans sa portée radar (220 NM,
  réglable dans la page de réglages du PC) et au-dessus de son horizon radar. Le
  relief n'est pas pris en compte. Une piste perdue reste 8 s. Sans AWACS ami
  en vol : « PAS D'AWACS — ENNEMIS MASQUÉS ».
- **MAP** : deux fonds de carte par théâtre, **VFR** et **BLANK** (choisis dans
  SET › CARTES sur la tablette, ou page **Théâtres** du PC), plus **WEB** (tuiles en ligne, si autorisées). Appui =
  VFR → BLANK → WEB → VFR… ; **appui long = OFF / ON** (OFF : grille seule ;
  un appui sur MAP OFF rallume le dernier fond). Par défaut, VFR = la carte du
  théâtre fournie avec BMS, calée en lat/long (Korea : `8_KTO_16k_Skyvector.png`,
  trouvée automatiquement dans les Docs) ; BLANK = aucune tant qu'elle n'est pas
  choisie. La 1re fois, l'appli la découpe en tuiles (≈ 20 s, ≈ 1,5 Go de RAM
  temporaire, ≈ 60 Mo dans `cache\maps\` à côté de l'exe) — fais-le de
  préférence avant de voler. Ensuite c'est instantané. Le calage devient exact
  quand l'appli a appris le repère du théâtre (≈ 20 NM de vol).

Une carte ouverte depuis **APT** peut aussi être épinglée (OSB **PIN**) : elle
apparaît ensuite dans les épinglées de la vue CHRT.

Page **STBY** : écran de secours intégré façon PFD moderne — horizon artificiel,
badin et altimètre à cadran (avec Mach, calage et sonde radio), HSI (cap, route,
CDI, relèvement, DME, TAS, temps restant), échelle de vario, et AoA / G /
carburant / RPM / FTIT, **marqueur de vecteur vitesse (FPM)** dans l'horizon
(décalé de l'incidence et du dérapage), et entre le HSI et le vario une **échelle de sonde
radio 0–3 000 ft** avec flèche creuse (« RA OFF » au-delà de 5 000 ft).
OSB : **MODE** (en haut à gauche : NAV → TCN → ILS → ILS TCN → NAV…),
**BARO ▲▼** (calage altimètre), **HDG ▲▼**, **CRS ▲▼**.

Look du CPD : bezel affiné, boutons gris souris avec point blanc, libellés des
OSB latéraux écrits verticalement (lettres de haut en bas), abrégés à la
manière des panneaux F-16 (PWR, SRCH, LNCH, HOFF, UNK, ALOW, CHK, RST…). Pour
les paires ▲/▼ ou +/− (BARO, HDG, CRS, RNG, STPT, BRT, PAGE, ZOOM, TXT…), le nom
de la fonction est écrit entre les deux boutons, et chaque bouton ne porte que
sa flèche ou son signe.

**Bezel 5 × 8** (voir docs/design-osb-simple.md) : 5 OSB en haut, 5 en bas, 8 de
chaque côté. Une touche de rangée = un affichage, toujours en plein écran :
en haut TSD · MFD · HSI · STBY · CHRT, en bas RWR · EWS · CHKL · BRIEF · SET.
**EWS** affiche RWR en haut (60 %) et EWS en bas (40 %) ; EWS à nouveau = RWR
seul. **SET** ouvre les réglages sur la moitié basse de l'écran, par-dessus
l'affichage en cours : SET à nouveau, RET, ou 10 s sans toucher = retour
(option dans SET : retour par la touche SET seulement) ; FULL = SET en plein
écran. Sous le RWR, l'EWS a PRG ▲/▼ en haut à droite, puis AUTO et BYP ;
OFF · STBY · MAN · SEMI à gauche. Les cadres HDG / CRS du HSI et du STBY sont à
hauteur des touches ▼ de leur paire.

**Angles du bezel** : à gauche **BRT ▲ / ▼** (luminosité de l'écran). En haut à
droite **RET** = retour direct : ferme SET s'il est ouvert ; sinon, sur une carte
ouverte depuis le TSD (APT, NAV), revient au TSD ; sinon revient à l'affichage
précédent (appuyer encore = retour à celui qu'on vient de quitter). Grisé quand
il n'y a rien à quoi revenir. En bas à droite **NITE** = mode nuit.

**Mode nuit** : le bezel et les boutons s'assombrissent et le point des boutons
s'allume en vert (rétroéclairage). Par défaut il est automatique : actif quand
la luminosité (BRT ▼) passe sous 50 %. **NITE** inverse le mode et le force
(« NITE MAN » sur la touche) : BRT ne le change plus jusqu'au prochain appui sur
NITE, qui le rebascule et revient en automatique. La bande verte de la touche
NITE est allumée quand le mode nuit est actif. BRT n'atténue que l'écran, pas
le bezel.

## 5. Le 3e MFD

C'est une **copie** du MFD gauche ou droit du cockpit (BMS n'affiche que deux MFD) :
appuyer sur un OSB de la tablette agit sur ce MFD dans BMS. Par défaut l'image
est affichée seule, carrée et aussi grande que possible (en 50/50, toute la
hauteur de la moitié basse). Les 20 OSB sont des zones tactiles invisibles sur
les bords de l'image, là où BMS dessine leurs libellés. Boutons du CPD :
MFD L / R, ZONE (montre les zones), CADR (ancien affichage avec cadre),
BRT ▲▼ (luminosité du MFD dans BMS), RLD (relancer le flux).

## 6. Commandes vers BMS (OSB, CMDS, ECM, RWR…)

Les boutons envoient les **callbacks de ton fichier .key** comme des touches clavier.
Un bouton marqué **∅** n'a pas de touche dans ton .key : assigne-lui une touche
dans BMS, puis recharge la page sur la tablette (l'appli revérifie aussi toute seule chaque minute). La liste des callbacks non
assignés est visible dans la page de réglages.

### Attribution automatique des touches manquantes

Dans la page de réglages, page **Falcon BMS** (carte « Touches des commandes »), le bouton
**« Attribuer les touches manquantes… »** (aussi proposé dans **Accueil**) propose une touche libre
pour chaque callback utilisé par le CPD qui n'en a pas :

1. **Fermez BMS avant d'appliquer** : BMS lit le fichier .key à son lancement
   (BMS-CPD refuse d'écrire tant que `Falcon BMS.exe` tourne).
2. L'aperçu liste chaque callback, sa fonction sur le CPD et la combinaison
   proposée. Combinaisons essayées dans l'ordre : **Ctrl+Alt+Shift**, puis
   **Ctrl+Shift**, puis **Alt+Shift**, chacun avec F1…F12, 1…0, A…Z et le pavé
   numérique 0…9 (174 combinaisons ; Ctrl+Alt seul est évité, c'est AltGr sur un
   clavier AZERTY). Une combinaison déjà
   présente dans le .key (touche ou premier appui d'un « combo ») n'est jamais
   réutilisée, et deux callbacks n'ont jamais la même. Les noms des lettres et
   chiffres sont ceux d'un clavier **QWERTY** (BMS enregistre la position physique :
   sur un AZERTY, « A » est la touche Q, « Q » la touche A, « W » la touche Z, « M » la
   touche « , »…).
3. Décochez ce que vous ne voulez pas, puis **Appliquer**. Le fichier est d'abord
   copié en `<fichier>.key.bak-AAAAMMJJ-HHMMSS` (même dossier), puis modifié :
   seules les lignes concernées changent (une ligne « non assignée » existante reçoit
   la touche ; un callback absent du fichier est ajouté à la fin avec la description
   `BMS-CPD`). Tout le reste (commentaires, ordre, fins de ligne) est conservé. Le
   fichier est relu et vérifié ; en cas d'échec, l'original est remis en place.
4. **Restaurer la sauvegarde** remet le .key tel qu'il était avant la dernière
   attribution automatique.

Les nouvelles touches apparaissent ensuite dans BMS (SETUP → CONTROLLERS → KEYS)
et peuvent y être changées comme les autres.

⚠️ Si BMS tourne **en administrateur**, lance aussi BMS-CPD en administrateur,
sinon Windows bloque les touches sans prévenir.

## 7. Ce qui reste à valider en vol réel (bêta)

- Rayons des cercles de menace (unité supposée en NM) et altitude des waypoints.
- Noms de certains callbacks ECM (`SimEcmMode1Toggle`…), marqués « probables ».
- Numéro du steerpoint courant (lu sur le DED) et focus de la fenêtre BMS.
- Cartes de théâtre : seule la carte Korea `8_KTO_16k_Skyvector.png` a un calage
  intégré ; les autres demandent un fichier `<carte>.georef.json` ou la même
  taille qu'une carte calée (voir 0.5.1). Sinon fond vectoriel ou tuiles en
  ligne (mode WEB) une fois que l'appli a calé la position (≈ 20 NM de vol).
- ILS : unité des barres `AdiIlsHorPos` / `AdiIlsVerPos` (supposée ±1 = pleine
  déviation, constante `bms.ILSFullScale`) et sens des barres à vérifier en vol.
- 0.6.0 : position des aéroports du menu du TSD (coordonnées réelles converties par
  le calage géographique de l'appli ; écart possible sur les théâtres dont la
  géographie BMS diffère) et déclinaison magnétique à régler pour CALC du 9-line.

Les réglages sont dans `bmscpd.json`, les checklists modifiables dans le dossier
`checklists\` (modèles à vérifier avec le Dash-1 BMS). Checklists : **checklist officielle BMS** T.O. BMS1F-16CJ-1CL-1 (F-16C/D
Block 52+, Change 1) convertie mot pour mot — procédures normales, vérification
intérieure du cockpit, **urgences** (OSB EMER) et ravitaillement en vol.
WARNING = cadre rayé rouge/blanc, CAUTION = rayé noir/jaune, NOTE = contour bleu
ciel. Champ `"category"` : `normal`, `emergency` ou `abnormal` ; `"warn"` affiche
un encadré avant l'étape. Les anciennes checklists modèles non modifiées sont
retirées automatiquement. Les nouveaux modèles des versions suivantes sont ajoutés sans toucher aux tiens. La mise à jour
automatique est désactivée pendant la bêta.

## Nouveautés 0.2.8-beta
- Page STBY : jauge **AOA** en ruban dans l'ADI, contre l'anémomètre (OSB AOA = afficher/masquer).
  Bandes : vert 11–15° (13° = on-speed), ambre 15–25°, rouge > 25°.
- Page STBY : calage barométrique sans fond noir.
- Page STBY : libellés AOA / G / FUEL / RPM / FTIT collés à leur valeur, FUEL centré.
- Page TSD : ligne STPT = TTG (temps restant) puis ETA (heure du jeu à l'arrivée au STPT).

## Nouveautés 0.2.9-beta
- Page MFD (mode plein, sans cadre) : OSB **FILL** — l'image du MFD prend toute la
  hauteur (côtés recadrés, sans déformation), pratique pour la vidéo du TGP.
  Les zones tactiles des OSB du MFD restent actives pour la partie visible.

## Nouveautés 0.3.0-beta — mise à jour automatique
- Au démarrage, BMS-CPD vérifie s'il existe une nouvelle version sur
  https://github.com/FuchyBe/BMS-CPD-releases (canal **beta**).
- Si oui, la page d'admin la propose avec ses notes : un clic télécharge l'exe,
  vérifie son empreinte SHA-256, remplace l'ancien et redémarre. Rien ne
  s'installe sans ton accord. Désactivable dans l'admin (Mises à jour).
- Toutes les versions restent téléchargeables à la main sur la page Releases.

## Nouveautés 0.4.0-beta
- Plus de fenêtre noire : BMS-CPD vit dans la zone de notification (clic droit : ouvrir l'admin, afficher / masquer le CPD, état de BMS, rechercher une mise à jour, quitter) ; le journal est écrit dans `bmscpd.log`.
- Installateur Windows `BMS-CPD-Setup-0.4.0-beta.exe` : installation sans droits administrateur, raccourcis menu Démarrer / Bureau, option « Lancer avec Windows » ; réglages et checklists gardés dans `%LOCALAPPDATA%\BMS-CPD` (conservés à la désinstallation, sauf si la case est cochée).
- Venant de la version portable : copier `bmscpd.json` et le dossier `checklists\` dans `%LOCALAPPDATA%\BMS-CPD` pour garder ses réglages.
- Écran étendu (DisplayLink…) : mode tactile « Overlay » — toucher la tablette ne retire plus le focus à BMS et le curseur de la souris ne bouge plus. En cas de souci : admin → mode tactile « Ancien mode ».
- Le CPD s'ouvre tout seul au démarrage sur la tablette mémorisée (choix du moniteur, mode tactile et « Autoriser la souris sur la tablette » dans l'admin).
- La page d'administration s'ouvre dans sa propre fenêtre.
- Affichage adapté à toutes les tablettes en portrait, du 3:4 (1536×2048) au 9:16 (1080×1920), sans bandes noires.
- Mises à jour : la version installée se met à jour via l'installateur (vérifié par SHA-256) puis redémarre ; la version portable remplace son exe.

## Nouveautés 0.4.1-beta — mission DTC
- BMS-CPD surveille `Data\Campaign\Save` (et le dossier Campaign du théâtre) et charge le
  fichier `.ini` de mission le plus récent, celui écrit par DTC → SAVE.
- Le nom de la mission (`[MISSION] title`) s'affiche dans la barre d'état.
- Hors du cockpit (préparation dans l'interface 2D), le TSD affiche ce plan : steerpoints,
  PPT avec leurs cercles de menace, lignes L1–L4 et terrains de dégagement (DIV),
  centré sur le STPT 1. Dès que tu es en vol, ce sont les données de l'avion qui priment.
- Le fond de carte avant le vol utilise la géoréférence mémorisée lors de ton dernier vol
  sur ce théâtre (au tout premier vol, il apparaît après quelques minutes de vol).

## Nouveautés 0.5.0-beta — bezel 5 × 8 simplifié
- Une touche de rangée = un affichage, toujours en plein écran avec 8 OSB de
  chaque côté : en haut TSD · MFD · HSI · STBY · CHRT, en bas RWR · EWS · CHKL ·
  BRIEF · SET. Plus de page MENU, de préréglages, de SWAP ni de partage libre.
- **EWS** = RWR en haut (60 %) et EWS en bas (40 %), avec ses 8 fonctions sur
  4 + 4 OSB (PRG ▲/▼ en haut à droite).
- **SET** s'ouvre sur la moitié basse par-dessus l'affichage en cours ; retour
  après 10 s sans toucher la moitié SET, par SET, par RET ou par une touche de
  rangée ; FULL = SET en plein écran.
- Angles : **BRT ▲ / ▼** à gauche, **RET** (retour direct) en haut à droite,
  **NITE** (mode nuit forcé / automatique) en bas à droite — voir section 4.
- Les anciens réglages d'affichage sont convertis automatiquement.

## Nouveautés 0.5.1-beta — cartes BLANK / VFR, ILS
- **TSD, OSB MAP** : deux cartes par théâtre, **VFR** et **BLANK**. Appui = VFR →
  BLANK → WEB (tuiles en ligne, seulement si autorisées dans SET) → VFR… ;
  appui long = fond **OFF / ON** (grille seule). Les anciens choix NONE / BMS /
  WEB sont convertis (NONE → OFF, BMS → VFR).
- **SET › CARTES DU TSD** : pour chaque théâtre (celui en cours et ceux dont une
  carte a été trouvée), choix de l'image VFR et de l'image BLANK parmi **toutes**
  les images PNG / JPEG trouvées dans les dossiers de cartes (Docs, Data\Add-On
  …\Docs, liens du théâtre ; ≥ 1024 px, nom ou dossier contenant « map »,
  « skyvector », « vfr », « blank »…). VFR **AUTO** = la carte calée de type
  Skyvector ; **AUCUNE** possible. Choix mémorisé sur le PC (`bmscpd.json`,
  `tsdMaps`, par théâtre, ex. `Korea|KTO`).
- **Calage** : une carte n'est utilisable que calée — calage intégré (Korea
  Skyvector), fichier `<carte>.georef.json` posé à côté de l'image (même format
  que les calages intégrés), ou **même taille en pixels** qu'une carte calée du
  même théâtre (les variantes d'une carte BMS partagent la même projection : le
  calage est réutilisé). Sinon « carte non calée » dans SET et sur le TSD, qui
  garde l'autre carte.
- **HSI** : lectures **BUG** (HDG) et **CRS** de nouveau centrées entre leurs
  deux touches ▲ / ▼ ; la rose est réduite si besoin.
- **ILS** (mode ILS/NAV ou ILS/TCN) : sur le HSI, échelle de glide (5 points) à
  droite de la rose avec son index, drapeaux rouges **GS** / **LOC** quand le
  signal n'est pas valide, annonce **ILS**, voyants **OM** (bleu) et **MM**
  (ambre). Sur STBY : barres de guidage ILS magenta sur l'ADI, échelles GS (bord
  droit) et LOC (bord bas) avec losanges, drapeaux GS / LOC, voyants OM / MM.
- À vérifier en vol : l'unité des positions de barres ILS exportées par BMS
  (supposées ±1 = pleine déviation ; valeurs brutes visibles dans
  `/api/state` → `hsi.ilsHorRaw` / `ilsVerRaw`).

## Nouveautés 0.6.0-beta (partie groupe)
- **Groupe d'escadron** : les joueurs partagent des documents (PDF, PNG, JPG, TXT,
  HTML, 12 Mo max) d'un PC à l'autre. Un joueur crée le groupe (SET → GROUPE →
  « Créer un groupe », ou page d'administration du PC, section « Groupe ») et
  transmet le **code** (ex. `VFS-7K2M-Q9XD`) et la **phrase secrète** ; les
  autres font « Rejoindre un groupe ». Chacun indique son **indicatif** (affiché
  comme expéditeur).
- **Transport** : relais public **ntfy.sh** (défaut, Internet), **dossier
  partagé** synchronisé (OneDrive, Google Drive, Dropbox…), ou **les deux**.
  Tout est chiffré de bout en bout (AES-256) : sans la phrase, le relais et le
  dossier ne voient que des données illisibles.
- **CHRT → SHRD** (OSB L5) : documents reçus (expéditeur, heure, NEW), ouverts
  dans la visionneuse plein écran ; **DEL** supprime de ce PC après confirmation
  (OUI / NON ; **TOUS** pour ses propres documents = supprimés chez tout le
  groupe). **SEND** (R5) : touchez un fichier du PC dans DOCS (ou SEND dans la
  visionneuse), tapez le titre, il part au groupe. Depuis le PC : page
  d'administration → « Envoyer un document au groupe ».
- À l'arrivée d'un document : message « Nouveau document de VIPER 1-2 » et
  compteur sur la touche **CHRT**.
- **Clavier à l'écran** façon UFC (grandes touches, chiffres, SYM, CLR, ENTR,
  ESC) pour tous les champs texte du CPD (indicatif, code, filtre…).
- Détails, sécurité et limites : `docs/share.md`.

## Nouveautés 0.6.0-beta (partie TSD / 9-line / scratchpad)
- **TSD — appui long sur la carte** (≈ 0,6 s, doigt immobile ; glisser déplace
  toujours la carte) : menu à l'endroit touché. **NOUVEAU POINT**, **ZONE CERCLE**,
  **ZONE POLYGONE**, **CAP**, **ANNULER**. Près d'un aéroport : son code OACI, **CARTES**
  (cartes de l'aérodrome dans CHRT, RET revient au TSD) et **METAR** (prévu dans une
  prochaine version). Sur un objet : **MODIFIER**, **DÉPLACER**, **ENVOYER AU GROUPE**,
  **SUPPRIMER**, **INFO**.
- **Objets tactiques** : camp ami (cyan) / hostile (rouge) / neutre (vert) / inconnu
  (jaune) ; points TGT, SAM, AAA, IP, CP, FARP, troupes amies, MARK ; zones menace,
  killbox, CAP, ROZ (hachurée), tirs amis ; altitude ou bloc d'altitude, note.
  **CAP** en hippodrome : 1er toucher = début de la branche chaude, 2e = fin, largeur
  10 NM, virages à droite (ou à gauche). Fiche plein cadre (clavier à l'écran),
  **DÉPLACER** = glisser l'objet ou ses poignées. **OBJ** (OSB L5 du TSD) affiche /
  masque les objets.
- Les objets restent **sur le PC** (toutes les tablettes les voient, même sans groupe)
  jusqu'à **ENVOYER AU GROUPE** ; ils apparaissent alors aussitôt chez les équipiers,
  avec l'indicatif de l'expéditeur. Tout membre peut **modifier** un objet du groupe
  (nouvelle révision chez tous) ; **TOUS** supprime ses propres envois chez tout le
  groupe.
- **CHKL → 9LN** (OSB L3) : 9-line CAS (format JTAC, lignes 1 à 9, remarques, TOT).
  Ligne 1 (IP) et ligne 6 (cible) : **TSD** = toucher un point ou un objet sur la carte
  (position, et altitude d'un point) ; **CALC** remplit les lignes 2 (cap magnétique,
  déclinaison réglable) et 3. Carte lisible type kneeboard, **SEND** au groupe ;
  à l'arrivée : « 9-line de VIPER 1-1 », compteur sur CHKL, la cible apparaît sur le
  TSD (appui long dessus = ouvrir le 9-line).
- **CHKL → NOTE** (OSB L4) : scratchpad (kneeboard) — dessin au doigt (4 couleurs,
  2 épaisseurs, gomme), texte au clavier, UNDO, CLR, plusieurs pages ◀ ▶, gardées sur
  le PC. **SEND** envoie la page (image + texte) au groupe ; **RCVD** liste les
  scratchpads reçus (suppression avec confirmation). 9LN et NOTE restent accessibles
  sous SET.
- Positions des aéroports : liste intégrée (Corée, Israël, Balkans, Hellas) +
  terrains de dégagement du DTC ; à compléter avec `airports.json` dans le dossier de
  données (`[["RKSO", "OSAN AB", 37.0906, 127.0297], …]`). Détails : `docs/share.md` §8.

## Nouveautés 0.6.1-beta
- **Attribution automatique des touches manquantes** (page de réglages, section
  Commandes) : aperçu, choix des callbacks, sauvegarde automatique du .key,
  vérification après écriture et bouton **Restaurer la sauvegarde**. Voir § 6.

## Interface simplifiée (branche ui-simple)

- **Page de réglages du PC** : menu à gauche, six pages — **Accueil** (état de BMS, de
  la tablette, du théâtre et de la version ; liste « À vérifier » avec un bouton de
  correction : User.cfg, touches manquantes, carte à préparer, mise à jour…),
  **Tablette** (Wi-Fi, USB, écran étendu), **Théâtres**, **Falcon BMS** (User.cfg,
  touches, Tacview / AWACS), **Groupe**, **Avancé** (mises à jour, chemins, serveur,
  rectangles MFD, diagnostic). Les détails sont repliés ou derrière « ? ».
- **Un menu par théâtre** (page Théâtres du PC et SET › CARTES de la tablette) :
  sélecteur de théâtre (celui en cours marqué), choix des cartes VFR et BLANK du
  TSD avec **aperçus** (AUTO / AUCUNE), état « calée / non calée », préparation des
  tuiles avec progression ; sur le PC, les documents du théâtre (charts, navaids,
  raccourcis) au même endroit.
- **SET** : quatre onglets AFFICHAGE · CARTES · GROUPE · SYSTÈME, une ligne par
  réglage, explications derrière « ? ».

## Nouveautés 0.6.2-beta
- Écran étendu : la fenêtre du CPD n'a plus de bouton dans la barre des tâches et ne
  clignote plus jamais (un bouton qui clignote empêchait la barre des tâches de se
  masquer automatiquement). En mode tactile Overlay, la fenêtre du CPD couvre tout
  l'écran de la tablette, au-dessus de la barre des tâches : les OSB du bas restent
  accessibles.

## Nouveautés 0.7.0-beta — interface simplifiée
- Admin (PC) : menu à gauche — Accueil (état en un coup d'œil + « À vérifier » avec
  boutons de correction), Tablette, Théâtres, Falcon BMS, Groupe, Avancé.
- Théâtres : un menu par théâtre avec le choix des cartes de fond VFR / BLANK du TSD
  (miniatures, calée / non calée, préparation des tuiles) et les documents du théâtre.
- SET (tablette) : 4 onglets AFFICHAGE · CARTES · GROUPE · SYSTÈME, grandes tuiles,
  aides derrière « ? ».

## Nouveautés 0.7.1-beta
- Israel : cartes `ITO_UI_Map_Airports_4K.png` et `ITO_Map_4K.png` calées (quadrillage
  de 30' détecté automatiquement, ≈ 7 600 points, écart moyen 0,3 pixel).

## Nouveautés 0.7.2-beta
- Cartes calées pour Hellas (`HellasMap4K_Airports`, `HellasMap8K`, `HellasMap16K`) et
  Balkans (`Balkans_UI_Map_16K`, `Balkans_Map_1_4K`) : quadrillage détecté
  automatiquement, contrôlé sur les villes et aérodromes.

