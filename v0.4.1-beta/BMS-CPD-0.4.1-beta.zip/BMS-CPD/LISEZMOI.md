# BMS-CPD 0.4.1-beta — mode d'emploi

CPD de F-16 Block 70/72 sur tablette Android, connecté à Falcon BMS 4.38.
Version portable : rien à installer, tout reste dans le dossier de l'exe.

## 1. Premier lancement (sans BMS, pour essayer)

1. Mets `BMS-CPD.exe` dans un dossier à lui (ex. `C:\Outils\BMS-CPD\`).
2. Lance-le **en mode démo** : clic droit dans le dossier → Terminal →
   `.\BMS-CPD.exe --mock`
   Un vol simulé en Corée démarre, et la page de réglages s'ouvre dans ton navigateur.
3. Autorise l'exe dans le pare-feu Windows (réseau **privé**) quand Windows le demande.

Pour l'usage normal avec BMS, lance simplement `BMS-CPD.exe` (double-clic).

## 2. Réglages BMS (une seule fois)

**Le plus simple :** dans la page de réglages de BMS-CPD, section
« Configuration BMS », clique « Ajouter / corriger les lignes ». Tu peux aussi
cocher « Vérifier et ajouter automatiquement… au démarrage » dans les Réglages.
Une sauvegarde `.bak` du fichier est faite avant chaque modification.
Redémarre BMS ensuite.

Le fichier se trouve dans le dossier d'installation de BMS, par exemple
`C:\Falcon BMS 4.38\User\Config\Falcon BMS User.cfg`. S'il n'existe pas,
BMS-CPD le crée. À la main, il faut y mettre :

```
set g_bExportRTTTextures 1     // copie des MFD pour le 3e MFD
set g_bTacviewRealTime 1       // datalink (optionnel, vue de tous les objets)
set g_bBriefHTML 1             // briefing en HTML (sinon texte)
```

Si tu passes par l'Alternative Launcher, vérifie qu'il n'écrase pas ce fichier.
Pour afficher le briefing sur la tablette, utilise le bouton « Print » dans l'écran
de briefing de BMS : le fichier est écrit dans `User\Briefings`.

## 3. Connecter la tablette

**Wi-Fi** : PC et tablette sur le même réseau. Ouvre dans Chrome l'adresse
affichée dans la console (ex. `http://192.168.1.20:8740`), puis touche ⛶ pour
passer en plein écran.

**USB (adb)** : active le débogage USB sur la tablette, branche-la, et clique
« Activer l'USB (adb reverse) » dans la page de réglages (il faut `adb.exe`, par ex. les
*platform-tools* Android à côté de l'exe). Sur la tablette, ouvre
`http://localhost:8740`. En USB, Chrome permet « Ajouter à l'écran d'accueil » :
l'appli s'ouvre alors en vrai plein écran.

**USB en écran étendu** : si la tablette est un moniteur Windows (spacedesk,
SuperDisplay…), choisis le moniteur dans la page de réglages et clique
« Ouvrir sur ce moniteur ». Dans ce mode, après chaque toucher sur le CPD,
BMS-CPD rend le focus à BMS et remet le curseur de la souris où il était ; la
fenêtre du CPD est aussi marquée « non activable » pour ne pas passer au
premier plan. Le mode Wi-Fi ou USB (navigateur de la tablette) n'a jamais ce
problème : c'est le mode recommandé.

## 4. Documents par théâtre (cartes, charts, navaids)

La page **DOCS** de la tablette a deux vues, choisies par les deux premiers OSB
de gauche :

- **CHRT** (par défaut) : les cartes d'aérodrome du **théâtre en cours**
  seulement. En haut, les cartes **épinglées** ; dessous, un bloc **par pays**
  (une touche le déplie / replie), puis une ligne par aérodrome (code OACI +
  nom ; s'il a plusieurs cartes, la ligne se déplie : ILS 27, TACAN 09…).
  Le champ filtre accepte un code OACI ou un nom. **PIN** (à droite de chaque
  carte, ou OSB **PIN** dans la visionneuse) épingle la carte pour ce théâtre ;
  **RST PIN** (à *maintenir*) retire toutes les épingles du théâtre.
  **EXP ALL / COL ALL** déplie / replie tous les pays, **NAV** ouvre la liste
  des navaids du théâtre.
- **DOCS** : l'explorateur complet — raccourcis du théâtre, favoris ★, dossier
  `Docs` de BMS ; **ALL** affiche les raccourcis de tous les théâtres.

Une carte (ou un document) s'ouvre **en plein écran** ; **RET** rend l'écran
tel qu'il était (split, pages). Dans la visionneuse : **PAGE ▲/▼**, **FIT W/P**,
**CHRT ▲/▼** (carte précédente / suivante du même aérodrome), **ZOOM + / −**,
**NGT**, **ROT**, **PIN**, **NAV LIST** ; pincer pour zoomer.

Les cartes sont lues dans les raccourcis du théâtre dont le nom contient
« Charts » (préremplis pour Korea, Balkans, Hellas et Israel : dossier
`…\Charts\<pays>\…`, un sous-dossier par pays, éventuellement un par
aérodrome) ; le code OACI est repris du nom du fichier (`LQSA Sarajevo.pdf`,
`RKSO ILS 27.pdf`) ou du sous-dossier. La liste des navaids est le raccourci
dont le nom contient « navaids ».

Pour ajouter un raccourci : page de réglages du PC → « Documents par théâtre » →
théâtre, nom, chemin d'un **dossier** (navigable sur la tablette) ou d'un
**fichier**. Chemin absolu (`D:\Cartes\Korea`) ou relatif au dossier BMS
(`Data\Add-On Balkans\Docs\02 Maps`). Majuscules, espaces en trop et extension
manquante sont tolérés. Les dossiers `Docs` de chaque add-on sont ajoutés
automatiquement.

Depuis la page **TSD** :
- **APT** ouvre la recherche de cartes d'aérodrome : onglets **OACI** (code,
  ex. LQSA), **NOM** (ex. Sarajevo), **TOUT**, et **NAVAIDS** (liste des navaids
  du théâtre en cours). La recherche porte sur les noms de fichiers des dossiers
  du théâtre et du dossier Docs de BMS. La carte s'ouvre **en plein écran** ;
  l'OSB **RET TSD** rend l'écran tel qu'il était (split, pages). Réglage SET →
  « Cartes APT / NAV » : plein écran ou autre moitié.
- **LBL** et **RING** : libellés et anneaux de distance, séparés.
- **Lignes du DTC** (L1 à L4, tracées par le créateur de mission ou dans le
  planificateur) : affichées avec le plan de vol (OSB **FPLN**), une couleur
  par ligne, nom de la ligne avec **LBL**.
- **DL** : **AWACS** (par défaut) → **AMIS** → **OFF**. En AWACS, les amis sont
  toujours affichés et un ennemi seulement s'il est vu par un AWACS ami (E-3,
  E-767, A-50…, ou indicatif DARKSTAR, MAGIC…) : dans sa portée radar (220 NM,
  réglable dans la page de réglages du PC) et au-dessus de son horizon radar. Le
  relief n'est pas pris en compte. Une piste perdue reste 8 s. Sans AWACS ami
  en vol : « PAS D'AWACS — ENNEMIS MASQUÉS ».
- **MAP BMS** : fond de carte = la carte du théâtre fournie avec BMS, calée en
  lat/long (Korea : `8_KTO_16k_Skyvector.png`, trouvée automatiquement dans les
  Docs). La 1re fois, l'appli la découpe en tuiles (≈ 20 s, ≈ 1,5 Go de RAM
  temporaire, ≈ 60 Mo dans `cache\maps\` à côté de l'exe) — fais-le de
  préférence avant de voler. Ensuite c'est instantané. Le calage devient exact
  quand l'appli a appris le repère du théâtre (≈ 20 NM de vol).

Une carte ouverte depuis **APT** peut aussi être épinglée (OSB **PIN**) : elle
apparaît ensuite dans les épinglées de la vue CHRT.

Page **STBY** : écran de secours intégré façon PFD moderne — horizon artificiel,
badin et altimètre à cadran (avec Mach, calage et sonde radio), HSI (cap, route,
CDI, relèvement, DME, TAS, temps restant), échelle de vario, et AoA / G /
carburant / RPM / FTIT, **marqueur de vecteur vitesse (FPM)** dans l'horizon
(décalé de l'incidence et du dérapage), et entre le HSI et le vario une **échelle de sonde
radio 0–3 000 ft** avec flèche creuse (« RA OFF » au-delà de 5 000 ft).
OSB : **MODE** (en haut à gauche : NAV → TCN → ILS → ILS TCN → NAV…),
**BARO ▲▼** (calage altimètre), **HDG ▲▼**, **CRS ▲▼**.

Look du CPD : bezel affiné, boutons gris souris avec point blanc, libellés des
OSB latéraux écrits verticalement (lettres de haut en bas), abrégés à la
manière des panneaux F-16 (PWR, SRCH, LNCH, HOFF, UNK, ALOW, CHK, RST…). Pour
les paires ▲/▼ ou +/− (BARO, HDG, CRS, RNG, STPT, BRT, PAGE, ZOOM, TXT…), le nom
de la fonction est écrit entre les deux boutons, et chaque bouton ne porte que
sa flèche ou son signe.

**Mode nuit** : quand la luminosité (BRT ▼) passe sous 50 %, le bezel et les
boutons s'assombrissent et le point des boutons s'allume en vert
(rétroéclairage). BRT n'atténue que l'écran, pas le bezel.

## 5. Le 3e MFD

C'est une **copie** du MFD gauche ou droit du cockpit (BMS n'affiche que deux MFD) :
appuyer sur un OSB de la tablette agit sur ce MFD dans BMS. Par défaut l'image
est affichée seule, carrée et aussi grande que possible (en 50/50, toute la
hauteur de la moitié basse). Les 20 OSB sont des zones tactiles invisibles sur
les bords de l'image, là où BMS dessine leurs libellés. Boutons du CPD :
MFD L / R, ZONE (montre les zones), CADR (ancien affichage avec cadre),
BRT ▲▼ (luminosité du MFD dans BMS), RLD (relancer le flux).

## 6. Commandes vers BMS (OSB, CMDS, ECM, RWR…)

Les boutons envoient les **callbacks de ton fichier .key** comme des touches clavier.
Un bouton marqué **∅** n'a pas de touche dans ton .key : assigne-lui une touche
dans BMS, puis recharge la page sur la tablette (l'appli revérifie aussi toute seule chaque minute). La liste des callbacks non
assignés est visible dans la page de réglages.

⚠️ Si BMS tourne **en administrateur**, lance aussi BMS-CPD en administrateur,
sinon Windows bloque les touches sans prévenir.

## 7. Ce qui reste à valider en vol réel (bêta)

- Rayons des cercles de menace (unité supposée en NM) et altitude des waypoints.
- Noms de certains callbacks ECM (`SimEcmMode1Toggle`…), marqués « probables ».
- Numéro du steerpoint courant (lu sur le DED) et focus de la fenêtre BMS.
- Pas de carte 2D de théâtre dans BMS 4.38 : fond noir vectoriel, ou tuiles en
  ligne (mode WEB) une fois que l'appli a calé la position (≈ 20 NM de vol).

Les réglages sont dans `bmscpd.json`, les checklists modifiables dans le dossier
`checklists\` (modèles à vérifier avec le Dash-1 BMS). Checklists : **checklist officielle BMS** T.O. BMS1F-16CJ-1CL-1 (F-16C/D
Block 52+, Change 1) convertie mot pour mot — procédures normales, vérification
intérieure du cockpit, **urgences** (OSB EMER) et ravitaillement en vol.
WARNING = cadre rayé rouge/blanc, CAUTION = rayé noir/jaune, NOTE = contour bleu
ciel. Champ `"category"` : `normal`, `emergency` ou `abnormal` ; `"warn"` affiche
un encadré avant l'étape. Les anciennes checklists modèles non modifiées sont
retirées automatiquement. Les nouveaux modèles des versions suivantes sont ajoutés sans toucher aux tiens. La mise à jour
automatique est désactivée pendant la bêta.

## Nouveautés 0.2.8-beta
- Page STBY : jauge **AOA** en ruban dans l'ADI, contre l'anémomètre (OSB AOA = afficher/masquer).
  Bandes : vert 11–15° (13° = on-speed), ambre 15–25°, rouge > 25°.
- Page STBY : calage barométrique sans fond noir.
- Page STBY : libellés AOA / G / FUEL / RPM / FTIT collés à leur valeur, FUEL centré.
- Page TSD : ligne STPT = TTG (temps restant) puis ETA (heure du jeu à l'arrivée au STPT).

## Nouveautés 0.2.9-beta
- Page MFD (mode plein, sans cadre) : OSB **FILL** — l'image du MFD prend toute la
  hauteur (côtés recadrés, sans déformation), pratique pour la vidéo du TGP.
  Les zones tactiles des OSB du MFD restent actives pour la partie visible.

## Nouveautés 0.3.0-beta — mise à jour automatique
- Au démarrage, BMS-CPD vérifie s'il existe une nouvelle version sur
  https://github.com/FuchyBe/BMS-CPD-releases (canal **beta**).
- Si oui, la page d'admin la propose avec ses notes : un clic télécharge l'exe,
  vérifie son empreinte SHA-256, remplace l'ancien et redémarre. Rien ne
  s'installe sans ton accord. Désactivable dans l'admin (Mises à jour).
- Toutes les versions restent téléchargeables à la main sur la page Releases.

## Nouveautés 0.4.0-beta
- Plus de fenêtre noire : BMS-CPD vit dans la zone de notification (clic droit : ouvrir l'admin, afficher / masquer le CPD, état de BMS, rechercher une mise à jour, quitter) ; le journal est écrit dans `bmscpd.log`.
- Installateur Windows `BMS-CPD-Setup-0.4.0-beta.exe` : installation sans droits administrateur, raccourcis menu Démarrer / Bureau, option « Lancer avec Windows » ; réglages et checklists gardés dans `%LOCALAPPDATA%\BMS-CPD` (conservés à la désinstallation, sauf si la case est cochée).
- Venant de la version portable : copier `bmscpd.json` et le dossier `checklists\` dans `%LOCALAPPDATA%\BMS-CPD` pour garder ses réglages.
- Écran étendu (DisplayLink…) : mode tactile « Overlay » — toucher la tablette ne retire plus le focus à BMS et le curseur de la souris ne bouge plus. En cas de souci : admin → mode tactile « Ancien mode ».
- Le CPD s'ouvre tout seul au démarrage sur la tablette mémorisée (choix du moniteur, mode tactile et « Autoriser la souris sur la tablette » dans l'admin).
- La page d'administration s'ouvre dans sa propre fenêtre.
- Affichage adapté à toutes les tablettes en portrait, du 3:4 (1536×2048) au 9:16 (1080×1920), sans bandes noires.
- Mises à jour : la version installée se met à jour via l'installateur (vérifié par SHA-256) puis redémarre ; la version portable remplace son exe.

## Nouveautés 0.4.1-beta — mission DTC
- BMS-CPD surveille `Data\Campaign\Save` (et le dossier Campaign du théâtre) et charge le
  fichier `.ini` de mission le plus récent, celui écrit par DTC → SAVE.
- Le nom de la mission (`[MISSION] title`) s'affiche dans la barre d'état.
- Hors du cockpit (préparation dans l'interface 2D), le TSD affiche ce plan : steerpoints,
  PPT avec leurs cercles de menace, lignes L1–L4 et terrains de dégagement (DIV),
  centré sur le STPT 1. Dès que tu es en vol, ce sont les données de l'avion qui priment.
- Le fond de carte avant le vol utilise la géoréférence mémorisée lors de ton dernier vol
  sur ce théâtre (au tout premier vol, il apparaît après quelques minutes de vol).

